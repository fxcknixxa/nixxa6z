import fetch from 'node-fetch';
const handler = async (m, {conn, usedPrefix, usedPrefix: _p, __dirname, text, isPrems}) => {
  if (usedPrefix == 'a' || usedPrefix == 'A') return;
  try {
    const pp =[imagen3,imagen1,imagen4].getRandom()
   // await conn.reply(m.chat,{ contextInfo:{ forwardingScore: 2022, isForwarded: true, externalAdReply: {title: 'wm', body: 'h', sourceUrl: nn, thumbnail:pp}}}  {quoted:m})
    // let vn = './media/menu.mp3'
    const img = './Menu2.jpg';
    const d = new Date(new Date + 3600000);
    const locale = 'es';
    const week = d.toLocaleDateString(locale, {weekday: 'long'});
    const date = d.toLocaleDateString(locale, {day: 'numeric', month: 'long', year: 'numeric'});
    const _uptime = process.uptime() * 1000;
    const uptime = clockString(_uptime);
    const user = global.db.data.users[m.sender];
    const {money, joincount} = global.db.data.users[m.sender];
    const {exp, limit, level, role} = global.db.data.users[m.sender];
    const rtotalreg = Object.values(global.db.data.users).filter((user) => user.registered == true).length;
    const more = String.fromCharCode(8206);
    const readMore = more.repeat(850);
    const taguser = '@' + m.sender.split('@s.whatsapp.net')[0];
    const doc = ['pdf', 'zip', 'vnd.openxmlformats-officedocument.presentationml.presentation', 'vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'vnd.openxmlformats-officedocument.wordprocessingml.document'];
    const document = doc[Math.floor(Math.random() * doc.length)];
    const str = `•❅──────✧❅✦❅✧──────❅•
╭═══〘 ❁❁❁❁❁❁❁ 〙═══╮
║        ✿~𝐒𝐤𝐲.𝐰𝐰𝐲𝐬 - 𝐛𝐨𝐭~✿
║•❅────✧❅✦❅✧────❅•║
║ ❀ 𝐇𝐨𝐥𝐚,  ${taguser}  *uwu*
║•❅────✧❅✦❅✧────❅•║
║ ❀ 𝐎𝐰𝐧𝐞𝐫:  𝐒𝐤𝐲.𝐰𝐰𝐲𝐬 
║ ❀ 𝐍𝐮𝐦𝐞𝐫𝐨:  wa.me/529931702706
║ ❀ 𝐁𝐨𝐭 𝐨𝐟𝐜:  wa.me/5219932620879
║ ❀ 𝐈𝐠: instagram.com/sky.wwys
║ ❀ 𝐅𝐞𝐜𝐡𝐚:  ${date}
║ ❀ 𝐓𝐢𝐞𝐦𝐩𝐨 𝐚𝐜𝐭𝐢𝐯𝐨:  ${uptime}
║ ❀ 𝐔𝐬𝐮𝐚𝐫𝐢𝐨𝐬: ${rtotalreg}
╰═══〘 ❁❁❁❁❁❁❁ 〙═══╯
    ${readMore}
 •❅──────✧❅✦❅✧──────❅•
╭═══〘 ❁❁❁❁❁❁ 〙═══╮
║  ❂𝐈𝐍𝐅𝐎 𝐃𝐄𝐋 𝐔𝐒𝐔𝐀𝐑𝐈𝐎❂
║• ❅───✧❅✦❅✧───❅ •║
║ ✾ 𝐍𝐢𝐯𝐞𝐥:  ${level}
║ ✾𝐄𝐱𝐩𝐞𝐫𝐢𝐞𝐧𝐜𝐢𝐚:  ${exp}
║ ✾ 𝐑𝐚𝐧𝐠𝐨:  ${role}
║ ✾ 𝐃𝐢𝐚𝐦𝐚𝐧𝐭𝐞𝐬:  ${limit}
║ ✾ 𝐏𝐞𝐣𝐞𝐜𝐨𝐢𝐧𝐬:  ${money}
║ ✾ 𝐓𝐨𝐤𝐞𝐧𝐬:  ${joincount}
║ ✯ 𝐏𝐫𝐞𝐦𝐢𝐮𝐦:  ${user.premiumTime > 0 ? '✔' : (isPrems ? '✔' : '✘') || ''}
╰═══〘 ❁❁❁❁❁❁ 〙═══╯
%sbot
•❅──────✧❅✦❅✧──────❅•
%readmore
╭═══〘 ❁❁❁❁❁❁ 〙═══╮
║ ❂𝐁𝐎𝐓 𝐎𝐅𝐂 𝐎 𝐒𝐔𝐁 𝐁𝐎𝐓❂
║• ❅───✧❅✦❅✧───❅  •║
║ ${(conn.user.jid == global.conn.user.jid ? '' : `Jadibot de: https://wa.me/${global.conn.user.jid.split`@`[0]}`) || '𝐄𝐬𝐭𝐞 𝐞𝐬 𝐞𝐥 𝐛𝐨𝐭 𝐨𝐟𝐢𝐜𝐢𝐚𝐥'}
╰═══〘 ❁❁❁❁❁❁ 〙═══╯
•❅──────✧❅✦❅✧──────❅•
╭═══〘 ❁❁❁❁❁❁ 〙═══╮
║            ❂ 𝐈𝐍𝐅𝐎 𝐁𝐎𝐓❂
║•❅─────✧❅✦❅✧─────❅•║
║ ❖ _${usedPrefix}𝐓𝐞𝐫𝐦𝐢𝐦𝐨𝐬𝐲𝐜𝐨𝐧𝐝𝐢𝐜𝐢𝐨𝐧𝐞𝐬_
║ ❖ _${usedPrefix}𝐆𝐫𝐮𝐩𝐨𝐬_
║ ❖ _${usedPrefix}𝐄𝐬𝐭𝐚𝐝𝐨_
║ ❖ _${usedPrefix}𝐈𝐧𝐟𝐨𝐛𝐨𝐭_
║ ❖ _${usedPrefix}𝐒𝐩𝐞𝐞𝐝𝐭𝐞𝐬𝐭_
║ ❖ _${usedPrefix}𝐃𝐨𝐧𝐚𝐫_
║ ❖ _${usedPrefix}𝐆𝐫𝐨𝐮𝐩𝐥𝐢𝐬𝐭_
║ ❖ _${usedPrefix}𝐎𝐰𝐧𝐞𝐫_
║ ❖ _${usedPrefix}𝐒𝐜𝐫𝐢𝐩𝐭_
║ ❖ _${usedPrefix}𝐋𝐢𝐬𝐭𝐩𝐫𝐞𝐦_
║ ❖ _𝐁𝐎𝐓_ (𝑢𝑠𝑜 𝑠𝑖𝑛 𝑝𝑟𝑒𝑓𝑖𝑗𝑜)
╰═══〘 ❁❁❁❁❁❁❁ 〙═══╯
•❅─────✧❅✦❅✧─────❅•
╭═══〘 ❁❁❁❁❁❁ 〙═══╮
║           ❂𝐒𝐄𝐑𝐁𝐎𝐓❂
║• ❅───✧❅✦❅✧───❅ •║
║ ⚘  _${usedPrefix}𝐒𝐞𝐫𝐛𝐨𝐭_
║ ⚘ _${usedPrefix}𝐒𝐭𝐨𝐩_
║ ⚘ _${usedPrefix}𝐁𝐨𝐭𝐬_
╰═══〘 ❁❁❁❁❁❁ 〙═══╯
•❅──────✧❅✦❅✧──────❅•
╭═══〘 ❁❁❁❁❁❁❁ 〙═══╮
║              ❂𝐉𝐔𝐄𝐆𝐎𝐒❂
║•❅──────✧❅✦❅✧─────❅•║
║ ◉  _${usedPrefix}𝐦𝐚𝐭𝐞𝐬  ◍𝐧𝐨𝐨𝐛 / 𝐞𝐚𝐬𝐲 / 𝐦𝐞𝐝𝐢𝐮𝐦 / 𝐡𝐚𝐫𝐝 / 𝐞𝐱𝐭𝐫𝐞𝐦𝐞 /𝐢𝐦𝐩𝐨𝐬𝐬𝐢𝐛𝐥𝐞 /𝐢𝐦𝐩𝐨𝐬𝐬𝐢𝐛𝐥𝐞𝟐◍_
║ ◉  _${usedPrefix}𝐩𝐩𝐭  ◍<𝐩𝐚𝐩𝐞𝐥 / 𝐭𝐢𝐣𝐞𝐫𝐚 /𝐩𝐢𝐞𝐝𝐫𝐚◍_
║ ◉  _${usedPrefix}𝐏𝐞𝐫𝐬𝐨𝐧𝐚𝐥𝐢𝐝𝐚𝐝 <𝐮𝐬𝐬𝐞𝐫>_
║ ◉  _${usedPrefix}𝐃𝐞𝐚𝐭𝐡𝐧𝐨𝐭𝐞 <𝐦𝐨𝐭𝐢𝐯𝐨><𝐮𝐬𝐮𝐚𝐫𝐢𝐨>_
║ ◉  _${usedPrefix}𝐅𝐨𝐥𝐥𝐚𝐫  <𝐮𝐬𝐬𝐞𝐫>_
║ ◉  _${usedPrefix}𝐀𝐦𝐢𝐠𝐨𝐫𝐚𝐦𝐝𝐨𝐦_
║ ◉  _${usedPrefix}𝐩𝐫𝐨𝐬𝐭𝐢𝐭𝐮𝐭𝐨  ◍𝐧𝐨𝐦𝐛𝐫𝐞 / @𝐭𝐚𝐠◍_
║ ◉  _${usedPrefix}𝐩𝐫𝐨𝐬𝐭𝐢𝐭𝐮𝐭𝐚  ◍𝐧𝐨𝐦𝐛𝐫𝐞 / @𝐭𝐚𝐠◍_
║ ◉  _${usedPrefix}𝐆𝐚𝐲𝟐  ◍𝐧𝐨𝐦𝐛𝐫𝐞 / @𝐭𝐚𝐠◍_
║ ◉  _${usedPrefix}𝐋𝐞𝐬𝐛𝐢𝐚𝐧𝐚  ◍𝐧𝐨𝐦𝐛𝐫𝐞 / @𝐭𝐚𝐠◍_
║ ◉  _${usedPrefix}𝐏𝐚𝐣𝐞𝐫𝐨  ◍𝐧𝐨𝐦𝐛𝐫𝐞 / @𝐭𝐚𝐠◍_
║ ◉  _${usedPrefix}𝐏𝐚𝐣𝐞𝐫𝐚  ◍𝐧𝐨𝐦𝐛𝐫𝐞 / @𝐭𝐚𝐠◍_
║ ◉  _${usedPrefix}𝐏𝐮𝐭𝐨  ◍𝐧𝐨𝐦𝐛𝐫𝐞 / @𝐭𝐚𝐠◍_
║ ◉  _${usedPrefix}𝐏𝐮𝐭𝐚  ◍𝐧𝐨𝐦𝐛𝐫𝐞 / @𝐭𝐚𝐠◍_
║ ◉  _${usedPrefix}𝐌𝐚𝐧𝐜𝐨  ◍𝐧𝐨𝐦𝐛𝐫𝐞 / @𝐭𝐚𝐠◍_
║ ◉  _${usedPrefix}𝐌𝐚𝐧𝐜𝐚  ◍𝐧𝐨𝐦𝐛𝐫𝐞 / @𝐭𝐚𝐠◍_
║ ◉  _${usedPrefix}𝐑𝐚𝐭𝐚  ◍𝐧𝐨𝐦𝐛𝐫𝐞 / @𝐭𝐚𝐠◍_
║ ◉  _${usedPrefix}𝐋𝐨𝐯𝐞  ◍𝐧𝐨𝐦𝐛𝐫𝐞 / @𝐭𝐚𝐠◍_
║ ◉  _${usedPrefix}𝐃𝐨𝐱𝐞𝐚𝐫  ◍𝐧𝐨𝐦𝐛𝐫𝐞 / @𝐭𝐚𝐠◍_
║ ◉  _${usedPrefix}𝐏𝐫𝐞𝐠𝐮𝐧𝐭𝐚  ◍𝐭𝐞𝐱𝐭𝐨◍_
║ ◉  _${usedPrefix}𝐬𝐥𝐨𝐭  ◍𝐚𝐩𝐮𝐞𝐬𝐭𝐚◍_
║ ◉  _${usedPrefix}𝐀𝐜𝐞𝐫𝐭𝐢𝐣𝐨_
║ ◉  _${usedPrefix}𝐒𝐢𝐦𝐢  ◍𝐭𝐞𝐱𝐭𝐨◍_
║ ◉  _${usedPrefix}𝐓𝐨𝐩  ◍𝐭𝐞𝐱𝐭𝐨◍_
║ ◉  _${usedPrefix}𝐓𝐨𝐩𝐠𝐚𝐲𝐬_
║ ◉  _${usedPrefix}𝐓𝐨𝐩𝐨𝐭𝐚𝐤𝐮𝐬_
║ ◉  _${usedPrefix}𝐅𝐨𝐫𝐦𝐚𝐫𝐩𝐚𝐫𝐞𝐣𝐚_
║ ◉  _${usedPrefix}𝐕𝐞𝐫𝐝𝐚𝐝_
║ ◉  _${usedPrefix}𝐑𝐞𝐭𝐨_
╰═══〘 ❁❁❁❁❁❁❁ 〙═══╯
•❅──────✧❅✦❅✧──────❅•
╭═══〘 ❁❁❁❁❁❁❁ 〙═══╮
║❂𝐀𝐂𝐓𝐈𝐕𝐀𝐑 𝐎 𝐃𝐄𝐒𝐀𝐂𝐓𝐈𝐕𝐀𝐑❂
║•❅─────✧❅✦❅✧─────❅•║
║ ✔  _${usedPrefix}𝐞𝐧𝐚𝐛𝐥𝐞 𝐰𝐞𝐥𝐜𝐨𝐦𝐞_
║ ✘  _${usedPrefix}𝐝𝐢𝐬𝐚𝐛𝐥𝐞 𝐰𝐞𝐥𝐜𝐨𝐦𝐞_
║ ✔ _${usedPrefix}𝐞𝐧𝐚𝐛𝐥𝐞 𝐦𝐨𝐝𝐨𝐡𝐨𝐫𝐧𝐲_
║ ✘  _${usedPrefix}𝐝𝐢𝐬𝐚𝐛𝐥𝐞 𝐦𝐨𝐝𝐨𝐡𝐨𝐫𝐧𝐲_
║ ✔  _${usedPrefix}𝐞𝐧𝐚𝐛𝐥𝐞 𝐚𝐧𝐭𝐢𝐥𝐢𝐧𝐤_
║ ✘  _${usedPrefix}𝐝𝐢𝐬𝐚𝐛𝐥𝐞 𝐚𝐧𝐭𝐢𝐥𝐢𝐧𝐤_
║ ✔  _${usedPrefix}𝐞𝐧𝐚𝐛𝐥𝐞 𝐚𝐧𝐭𝐢𝐥𝐢𝐧𝐤𝟐_
║ ✘  _${usedPrefix}𝐝𝐢𝐬𝐚𝐛𝐥𝐞 𝐚𝐧𝐭𝐢𝐥𝐢𝐧𝐤𝟐_
║ ✔  _${usedPrefix}𝐞𝐧𝐚𝐛𝐥𝐞 𝐝𝐞𝐭𝐞𝐜𝐭_
║ ✘  _${usedPrefix}𝐝𝐢𝐬𝐚𝐛𝐥𝐞 𝐝𝐞𝐭𝐞𝐜𝐭_
║ ✔  _${usedPrefix}𝐞𝐧𝐚𝐛𝐥𝐞 𝐚𝐮𝐝𝐢𝐨𝐬_
║ ✘  _${usedPrefix}𝐝𝐢𝐬𝐚𝐛𝐥𝐞 𝐚𝐮𝐝𝐢𝐨𝐬_
║ ✔  _${usedPrefix}𝐞𝐧𝐚𝐛𝐥𝐞 𝐚𝐮𝐭𝐨𝐬𝐭𝐢𝐜𝐤𝐞𝐫_
║ ✘  _${usedPrefix}𝐝𝐢𝐬𝐚𝐛𝐥𝐞 𝐚𝐮𝐭𝐨𝐬𝐭𝐢𝐜𝐤𝐞𝐫_
║ ✔  _${usedPrefix}𝐞𝐧𝐚𝐛𝐥𝐞 𝐚𝐧𝐭𝐢𝐯𝐢𝐞𝐰𝐨𝐧𝐜𝐞_
║ ✘  _${usedPrefix}𝐝𝐢𝐬𝐚𝐛𝐥𝐞 𝐚𝐧𝐭𝐢𝐯𝐢𝐞𝐰𝐨𝐧𝐜𝐞_
║ ✔  _${usedPrefix}𝐞𝐧𝐚𝐛𝐥𝐞 𝐚𝐧𝐭𝐢𝐭𝐨𝐱𝐢𝐜_
║ ✘  _${usedPrefix}𝐝𝐢𝐬𝐚𝐛𝐥𝐞 𝐚𝐧𝐭𝐢𝐭𝐨𝐱𝐢𝐜_
║ ✔  _${usedPrefix}𝐞𝐧𝐚𝐛𝐥𝐞 𝐚𝐧𝐭𝐢𝐭𝐫𝐚𝐛𝐚_
║ ✘  _${usedPrefix}𝐝𝐢𝐬𝐚𝐛𝐥𝐞 𝐚𝐧𝐭𝐢𝐭𝐫𝐚𝐛𝐚_
║ ✔  _${usedPrefix}𝐞𝐧𝐚𝐛𝐥𝐞 𝐚𝐧𝐭𝐢𝐚𝐫𝐚𝐛𝐞𝐬_
║ ✘  _${usedPrefix}𝐝𝐢𝐬𝐚𝐛𝐥𝐞 𝐚𝐧𝐭𝐢𝐚𝐫𝐚𝐛𝐞𝐬_
║ ✔  _${usedPrefix}𝐞𝐧𝐚𝐛𝐥𝐞 𝐦𝐨𝐝𝐨𝐚𝐝𝐦𝐢𝐧_
║ ✘  _${usedPrefix}𝐝𝐢𝐬𝐚𝐛𝐥𝐞 𝐦𝐨𝐝𝐨𝐚𝐝𝐦𝐢𝐧_
╰═══〘 ❁❁❁❁❁❁ 〙═══╯
•❅──────✧❅✦❅✧──────❅•
╭═══〘 ❁❁❁❁❁❁❁ 〙═══╮
║        ❂𝐃𝐄𝐒𝐂𝐀𝐑𝐆𝐀𝐒❂
║•❅─────✧❅✦❅✧─────❅•║
║◉  _${usedPrefix}𝐢𝐧𝐬𝐭𝐚𝐠𝐫𝐚𝐦 <𝐞𝐧𝐥𝐚𝐜𝐞 / 𝐥𝐢𝐧𝐤 / 𝐮𝐫𝐥>_
║◉  _${usedPrefix}𝐢𝐧𝐬𝐭𝐚𝐠𝐫𝐚𝐦𝟐 <𝐞𝐧𝐥𝐚𝐜𝐞 / 𝐥𝐢𝐧𝐤 / 𝐮𝐫𝐥>_
║◉  _${usedPrefix}𝐢𝐧𝐬𝐭𝐚𝐠𝐫𝐚𝐦𝟑 <𝐞𝐧𝐥𝐚𝐜𝐞 / 𝐥𝐢𝐧𝐤 / 𝐮𝐫𝐥>_
║◉  _${usedPrefix}𝐦𝐞𝐝𝐢𝐚𝐟𝐢𝐫𝐞 <𝐞𝐧𝐥𝐚𝐜𝐞 / 𝐥𝐢𝐧𝐤 / 𝐮𝐫𝐥>_
║◉  _${usedPrefix}𝐭𝐢𝐤𝐭𝐨𝐤 <𝐞𝐧𝐥𝐚𝐜𝐞 / 𝐥𝐢𝐧𝐤 / 𝐮𝐫𝐥>_
║◉  _${usedPrefix}𝐱𝐧𝐱𝐱𝐝𝐥 *<𝐞𝐧𝐥𝐚𝐜𝐞 / 𝐥𝐢𝐧𝐤 / 𝐮𝐫𝐥>_
║◉  _${usedPrefix}𝐱𝐯𝐢𝐝𝐞𝐨𝐬𝐝𝐥 <𝐞𝐧𝐥𝐚𝐜𝐞 / 𝐥𝐢𝐧𝐤 / 𝐮𝐫𝐥>_
║◉  _${usedPrefix}𝐭𝐰𝐢𝐭𝐭𝐞𝐫 <𝐞𝐧𝐥𝐚𝐜𝐞 / 𝐥𝐢𝐧𝐤 / 𝐮𝐫𝐥>_
║◉  _${usedPrefix}𝐟𝐛 <𝐞𝐧𝐥𝐚𝐜𝐞 / 𝐥𝐢𝐧𝐤 / 𝐮𝐫𝐥>_
║◉  _${usedPrefix}𝐲𝐭𝐦𝐩𝟑 <𝐞𝐧𝐥𝐚𝐜𝐞 / 𝐥𝐢𝐧𝐤 / 𝐮𝐫𝐥>_
║◉  _${usedPrefix}𝐲𝐭𝐦𝐩𝟒 <𝐞𝐧𝐥𝐚𝐜𝐞 / 𝐥𝐢𝐧𝐤 / 𝐮𝐫𝐥>_
║◉  _${usedPrefix}𝐲𝐭𝐦𝐩𝟑𝐝𝐨𝐜 <𝐞𝐧𝐥𝐚𝐜𝐞 / 𝐥𝐢𝐧𝐤 / 𝐮𝐫𝐥>_
║◉  _${usedPrefix}𝐲𝐭𝐦𝐩𝟒𝐝𝐨𝐜 <𝐞𝐧𝐥𝐚𝐜𝐞 / 𝐥𝐢𝐧𝐤 / 𝐮𝐫𝐥>_
║◉  _${usedPrefix}𝐯𝐢𝐝𝐞𝐨𝐝𝐨𝐜 <𝐞𝐧𝐥𝐚𝐜𝐞 / 𝐥𝐢𝐧𝐤 / 𝐮𝐫𝐥>_
║◉  _${usedPrefix}𝐝𝐚𝐩𝐤𝟐 <𝐞𝐧𝐥𝐚𝐜𝐞 / 𝐥𝐢𝐧𝐤 / 𝐮𝐫𝐥>_
║◉  _${usedPrefix}𝐬𝐭𝐢𝐜𝐤𝐞𝐫𝐩𝐚𝐜𝐤 <𝐞𝐧𝐥𝐚𝐜𝐞 / 𝐥𝐢𝐧𝐤 / 𝐮𝐫𝐥>_
║◉  _${usedPrefix}𝐩𝐥𝐚𝐲𝐝𝐨𝐜 <𝐭𝐞𝐱𝐭𝐨>_
║◉  _${usedPrefix}𝐩𝐥𝐚𝐲𝐥𝐢𝐬𝐭 <𝐭𝐞𝐱𝐭𝐨>_
║◉  _${usedPrefix}𝐩𝐥𝐚𝐲𝐥𝐢𝐬𝐭𝟐 <𝐭𝐞𝐱𝐭𝐨>_
║◉  _${usedPrefix}𝐬𝐩𝐨𝐭𝐢𝐟𝐲 <𝐭𝐞𝐱𝐭𝐨>_
║◉  _${usedPrefix}𝐬𝐨𝐮𝐧𝐝𝐜𝐥𝐨𝐮𝐝 <𝐭𝐞𝐱𝐭𝐨>_
║◉  _${usedPrefix}𝐢𝐦𝐚𝐠𝐞𝐧 <𝐭𝐞𝐱𝐭𝐨>_
║◉  _${usedPrefix}𝐩𝐢𝐧𝐭𝐞𝐫𝐞𝐬𝐭 <𝐭𝐞𝐱𝐭𝐨>_
║◉  _${usedPrefix}𝐰𝐚𝐥𝐥𝐩𝐚𝐩𝐞𝐫 <𝐭𝐞𝐱𝐭𝐨>_
║◉  _${usedPrefix}𝐰𝐚𝐥𝐥𝐩𝐚𝐩𝐞𝐫𝟐 <𝐭𝐞𝐱𝐭𝐨>_
║◉  _${usedPrefix}𝐢𝐠𝐬𝐭𝐨𝐫𝐲 <𝐧𝐨𝐦𝐛𝐫𝐞 𝐝𝐞 𝐮𝐬𝐮𝐚𝐫𝐢𝐨>_
╰═══〘 ❁❁❁❁❁❁❁ 〙═══╯
•──────✧❅✦❅✧──────•
╭═══〘 ❁❁❁❁❁❁❁❁ 〙═══╮
║              ❂𝐆𝐑𝐔𝐏𝐎𝐒❂
║•❅─────✧❅✦❅✧─────❅•║
║☬  _${usedPrefix}𝐚𝐝𝐝 <𝐧𝐮𝐦𝐞𝐫𝐨>_
║☬  _${usedPrefix}𝐤𝐢𝐜𝐤 <@𝐭𝐚𝐠>_
║☬  _${usedPrefix}𝐤𝐢𝐜𝐤𝟐 <@𝐭𝐚𝐠>_
║☬  _${usedPrefix}𝐥𝐢𝐬𝐭𝐚𝐧𝐮𝐦 <𝐭𝐞𝐱𝐭𝐨>_
║☬  _${usedPrefix}𝐤𝐢𝐜𝐤𝐧𝐮𝐦 <𝐭𝐞𝐱𝐭𝐨>_
║☬  _${usedPrefix}𝐠𝐫𝐮𝐩𝐨 <𝐚𝐛𝐫𝐢𝐫 / 𝐜𝐞𝐫𝐫𝐚𝐫>_
║☬  _${usedPrefix}𝐠𝐫𝐨𝐮𝐩𝐭𝐢𝐦𝐞 <𝐨𝐩𝐜𝐢𝐨𝐧> <𝐭𝐢𝐞𝐦𝐩𝐨>_
║☬  _${usedPrefix}𝐩𝐫𝐨𝐦𝐨𝐭𝐞 <@𝐭𝐚𝐠>_
║☬  _${usedPrefix}𝐝𝐞𝐦𝐨𝐭𝐞 <@𝐭𝐚𝐠>_
║☬  _𝐚𝐝𝐦𝐢𝐧𝐬 <𝐭𝐞𝐱𝐭𝐨>_ (𝑢𝑠𝑜 𝑠𝑖𝑛 𝑝𝑟𝑒𝑓𝑖𝑗𝑜)
║☬  _${usedPrefix}𝐢𝐧𝐟𝐨𝐠𝐫𝐨𝐮𝐩_
║☬  _${usedPrefix}𝐫𝐞𝐬𝐞𝐭𝐥𝐢𝐧𝐤_
║☬  _${usedPrefix}𝐥𝐢𝐧𝐤_
║☬  _${usedPrefix}𝐬𝐞𝐭𝐧𝐚𝐦𝐞 <𝐭𝐞𝐱𝐭𝐨>_
║☬  _${usedPrefix}𝐬𝐞𝐭𝐝𝐞𝐬𝐜 <𝐭𝐞𝐱𝐭𝐨>_
║☬  _${usedPrefix}𝐢𝐧𝐯𝐨𝐜𝐚𝐫 <𝐭𝐞𝐱𝐭𝐨>_
║☬  _${usedPrefix}𝐬𝐞𝐭𝐰𝐞𝐥𝐜𝐨𝐦𝐞 <𝐭𝐞𝐱𝐭𝐨>_
║☬  _${usedPrefix}𝐬𝐞𝐭𝐛𝐲𝐞 <𝐭𝐞𝐱𝐭𝐨>_
║☬  _${usedPrefix}𝐡𝐢𝐝𝐞𝐭𝐚𝐠 <𝐭𝐞𝐱𝐭𝐨>_
║☬  _${usedPrefix}𝐡𝐢𝐝𝐞𝐭𝐚𝐠 <𝐚𝐮𝐝𝐢𝐨>_
║☬  _${usedPrefix}𝐡𝐢𝐝𝐞𝐭𝐚𝐠 <𝐯𝐢𝐝𝐞𝐨>_
║☬  _${usedPrefix}𝐡𝐢𝐝𝐞𝐭𝐚𝐠 <𝐢𝐦𝐚𝐠𝐞𝐧>_
║☬  _${usedPrefix}𝐬𝐞𝐭𝐩𝐩 <𝐢𝐦𝐚𝐠𝐞𝐧>_
╰═══〘 ❁❁❁❁❁❁❁❁ 〙═══╯
•❅──────✧❅✦❅✧──────❅•

╭═══〘 ❁❁❁❁❁❁❁ 〙═══╮
║   ❂𝐂𝐎𝐍𝐕𝐄𝐑𝐓𝐈𝐃𝐎𝐑𝐄𝐒❂
║•❅─────✧❅✦❅✧─────❅•║
║۞  _${usedPrefix}𝐓𝐨𝐚𝐧𝐢𝐦𝐞 <𝐢𝐦𝐚𝐠𝐞𝐧>_
║۞  _${usedPrefix}𝐓𝐨𝐠𝐢𝐟𝐚𝐮𝐥𝐝 <𝐯𝐢𝐝𝐞𝐨>_
║۞  _${usedPrefix}𝐓𝐨𝐢𝐦𝐠 <𝐬𝐭𝐢𝐜𝐤𝐞𝐫>_
║۞  _${usedPrefix}𝐓𝐨𝐦𝐩𝟑 <𝐯𝐢𝐝𝐞𝐨>_
║۞  _${usedPrefix}𝐓𝐨𝐦𝐩𝟑 <𝐧𝐨𝐭𝐚 𝐝𝐞 𝐯𝐨𝐳>_
║۞  _${usedPrefix}𝐓𝐨𝐩𝐭𝐭 <𝐯𝐢𝐝𝐞𝐨 / 𝐚𝐮𝐝𝐢𝐨>_
║۞  _${usedPrefix}𝐓𝐨𝐯𝐢𝐝𝐞𝐨 <𝐬𝐭𝐢𝐜𝐤𝐞𝐫>_
║۞  _${usedPrefix}𝐓𝐨𝐮𝐫𝐥 <𝐯𝐢𝐝𝐞𝐨 / 𝐢𝐦𝐚𝐠𝐞𝐧 / 𝐚𝐮𝐝𝐢𝐨>_
║۞  _${usedPrefix}𝐓𝐭𝐬 𝐞𝐬 <𝐭𝐞𝐱𝐭𝐨>_
╰═══〘 ❁❁❁❁❁❁❁❁ 〙═══╯
•❅──────✧❅✦❅✧──────❅•
╭═══〘 ❁❁❁❁❁❁❁❁ 〙═══╮
║ ❂𝐄𝐅𝐄𝐂𝐓𝐎𝐒 𝐘 𝐋𝐎𝐆𝐎𝐒❂
║•❅─────✧❅✦❅✧─────❅•║
║❋ _${usedPrefix}𝐏𝐡𝐦𝐚𝐤𝐞𝐫 <𝐨𝐩𝐜𝐢𝐨𝐧><𝐢𝐦𝐚𝐠𝐞𝐧>_
║❋ _${usedPrefix}𝐋𝐨𝐠𝐨𝐬 <𝐞𝐟𝐞𝐜𝐭𝐨 ><𝐭𝐞𝐱𝐭𝐨>_
║❋ _${usedPrefix}𝐋𝐨𝐠𝐨𝐜𝐡𝐫𝐢𝐬𝐭𝐦𝐚𝐬 <𝐭𝐞𝐱𝐭𝐨>_
║❋ _${usedPrefix}𝐋𝐨𝐠𝐨𝐜𝐨𝐫𝐚𝐳𝐨𝐧 <𝐭𝐞𝐱𝐭𝐨>_
║❋ _${usedPrefix}𝐘𝐭𝐜𝐨𝐦𝐦𝐞𝐧𝐭 <𝐭𝐞𝐱𝐭𝐨>_
║❋ _${usedPrefix}𝐇𝐨𝐫𝐧𝐲𝐜𝐚𝐫𝐝 <@𝐭𝐚𝐠>_
║❋ _${usedPrefix}𝐒𝐢𝐦𝐩𝐜𝐚𝐫𝐝 <@𝐭𝐚𝐠>_
║❋ _${usedPrefix}𝐋𝐨𝐥𝐢𝐜𝐞 <@𝐭𝐚𝐠>_
║❋ _${usedPrefix}𝐈𝐭𝐬𝐬𝐨𝐬𝐭𝐮𝐩𝐢𝐝_
║❋ _${usedPrefix}𝐏𝐢𝐱𝐞𝐥𝐚𝐫_
║❋ _${usedPrefix}𝐁𝐥𝐮𝐫_
╰═══〘 ❁❁❁❁❁❁❁ 〙═══╯
•❅──────✧❅✦❅✧──────❅•
╭═══〘 ❁❁❁❁❁❁❁ 〙═══╮
║       ❂𝐅𝐑𝐀𝐒𝐄𝐒 𝐘 𝐓𝐄𝐗𝐓𝐎❂
║•❅────✧❅✦❅✧────❅ •║
║✦ _${usedPrefix}𝐏𝐢𝐫𝐨𝐩𝐨_
║✦ _${usedPrefix}𝐂𝐨𝐧𝐬𝐞𝐣𝐨_
║✦ _${usedPrefix}𝐅𝐫𝐚𝐬𝐞𝐫𝐨𝐦𝐚𝐧𝐭𝐢𝐜𝐚_
║✦ _${usedPrefix}𝐇𝐢𝐬𝐭𝐨𝐫𝐢𝐚𝐫𝐨𝐦𝐚𝐧𝐭𝐢𝐜𝐚_
╰═══〘 ❁❁❁❁❁❁❁ 〙═══╯
•❅──────✧❅✦❅✧──────❅•
╭═══〘 ❁❁❁❁❁❁❁ 〙═══╮
║              ❂𝐑𝐀𝐍𝐃𝐎𝐌❂
║•❅────✧❅✦❅✧────❅•║
║꙳ _${usedPrefix}𝐤𝐩𝐨𝐩 <𝐛𝐥𝐚𝐜𝐤𝐩𝐢𝐧𝐤 / 𝐞𝐱𝐨 / 𝐛𝐭𝐬>_
║꙳ _${usedPrefix}𝐜𝐫𝐢𝐬𝐭𝐢𝐚𝐧𝐨𝐫𝐨𝐧𝐚𝐥𝐝𝐨_
║꙳ _${usedPrefix}𝐦𝐞𝐬𝐬𝐢_
║꙳ _${usedPrefix}𝐜𝐚𝐭_
║꙳ _${usedPrefix}𝐝𝐨𝐠_
║꙳ _${usedPrefix}𝐦𝐞𝐦𝐞_
║꙳ _${usedPrefix}𝐢𝐭𝐳𝐲_
║꙳ _${usedPrefix}𝐛𝐥𝐚𝐜𝐤𝐩𝐢𝐧𝐤_
║꙳ _${usedPrefix}𝐥𝐨𝐥𝐢_
║꙳ _${usedPrefix}𝐧𝐚𝐯𝐢𝐝𝐚𝐝_
║꙳ _${usedPrefix}𝐩𝐩𝐜𝐨𝐮𝐩𝐥𝐞_
║꙳ _${usedPrefix}𝐰𝐩𝐦𝐨𝐧𝐭𝐚ñ𝐚_
║꙳ _${usedPrefix}𝐩𝐮𝐛𝐠_
║꙳ _${usedPrefix}𝐰𝐩𝐠𝐚𝐦𝐢𝐧𝐠_
║꙳ _${usedPrefix}𝐰𝐩𝐚𝐞𝐬𝐭𝐡𝐞𝐭𝐢𝐜_
║꙳ _${usedPrefix}𝐰𝐩𝐚𝐞𝐬𝐭𝐡𝐞𝐭𝐢𝐜𝟐_
║꙳ _${usedPrefix}𝐰𝐩𝐫𝐚𝐧𝐝𝐨𝐦_
║꙳ _${usedPrefix}𝐰𝐚𝐥𝐥𝐡𝐩_
║꙳ _${usedPrefix}𝐰𝐩𝐯𝐞𝐡𝐢𝐜𝐮𝐥𝐨_
║꙳ _${usedPrefix}𝐰𝐩𝐦𝐨𝐭𝐨_
║꙳ _${usedPrefix}𝐜𝐨𝐟𝐟𝐞𝐞_
║꙳ _${usedPrefix}𝐩𝐞𝐧𝐭𝐨𝐥_
║꙳ _${usedPrefix}𝐜𝐚𝐫𝐢𝐜𝐚𝐭𝐮𝐫𝐚_
║꙳ _${usedPrefix}𝐜𝐢𝐛𝐞𝐫𝐞𝐬𝐩𝐚𝐜𝐢𝐨_
║꙳ _${usedPrefix}𝐭𝐞𝐜𝐡𝐧𝐨𝐥𝐨𝐠𝐲_
║꙳ _${usedPrefix}𝐝𝐨𝐫𝐚𝐞𝐦𝐨𝐧_
║꙳ _${usedPrefix}𝐧𝐞𝐤𝐨_
║꙳ _${usedPrefix}𝐰𝐚𝐢𝐟𝐮_
║꙳ _${usedPrefix}𝐚𝐤𝐢𝐫𝐚_
║~ _${usedPrefix}𝐚𝐤𝐢𝐲𝐚𝐦𝐚_
║꙳ _${usedPrefix}𝐚𝐬𝐮𝐧𝐚_
║꙳ _${usedPrefix}𝐚𝐲𝐮𝐳𝐚𝐰𝐚_
║꙳ _${usedPrefix}𝐜𝐡𝐢𝐡𝐨_
║꙳ _${usedPrefix}𝐜𝐡𝐢𝐭𝐨𝐠𝐞_
║꙳ _${usedPrefix}𝐝𝐞𝐢𝐝𝐚𝐫𝐚_
║꙳ _${usedPrefix}𝐞𝐥𝐚𝐢𝐧𝐚_
║꙳ _${usedPrefix}𝐞𝐦𝐢𝐥𝐢𝐚_
║꙳ _${usedPrefix}𝐡𝐞𝐬𝐭𝐢𝐚_
║꙳ _${usedPrefix}𝐡𝐢𝐧𝐚𝐭𝐚_
║꙳ _${usedPrefix}𝐢𝐧𝐨𝐫_
║꙳ _${usedPrefix}𝐢𝐬𝐮𝐳𝐮_
║꙳ _${usedPrefix}𝐢𝐭𝐚𝐜𝐡𝐢_
║꙳ _${usedPrefix}𝐤𝐚𝐨𝐫𝐢_
║꙳ _${usedPrefix}𝐤𝐞𝐧𝐞𝐤𝐢_
║꙳ _${usedPrefix}𝐤𝐮𝐫𝐮𝐦𝐢_
║꙳ _${usedPrefix}𝐦𝐚𝐝𝐚𝐫𝐚_
║꙳ _${usedPrefix}𝐦𝐢𝐤𝐚𝐬𝐚_
║꙳ _${usedPrefix}𝐦𝐢𝐤𝐮_
║꙳ _${usedPrefix}𝐦𝐢𝐧𝐚𝐭𝐨_
║꙳ _${usedPrefix}𝐧𝐚𝐫𝐮𝐭𝐨_
║꙳ _${usedPrefix}𝐧𝐞𝐳𝐮𝐤𝐨_
║꙳ _${usedPrefix}𝐬𝐚𝐠𝐢𝐫𝐢_
║꙳ _${usedPrefix}𝐜𝐨𝐬𝐩𝐥𝐚𝐲_
╰═══〘 ❁❁❁❁❁❁❁ 〙═══╯
•❅──────✧❅✦❅✧──────❅•

╭═══〘 ❁❁❁❁❁❁❁ 〙═══╮
║     ❂𝐂𝐎𝐌𝐀𝐍𝐃𝐎𝐒 +𝟏𝟖❂
║•❅─────✧❅✦❅✧─────❅•║
║🔞 _${usedPrefix}𝐏𝐚𝐜𝐤_
║🔞 _${usedPrefix}𝐏𝐚𝐜𝐤𝟐_
║🔞 _${usedPrefix}𝐏𝐚𝐜𝐤𝟑_
║🔞 _${usedPrefix}𝐕𝐢𝐝𝐞𝐨𝐱𝐱𝐱_
║🔞 _${usedPrefix}𝐕𝐢𝐝𝐞𝐨𝐥𝐞𝐬𝐛𝐢𝐱𝐱𝐱_
║🔞 _${usedPrefix}𝐓𝐞𝐭𝐚𝐬_
║🔞 _${usedPrefix}𝐁𝐨𝐨𝐭𝐲_
║🔞 _${usedPrefix}𝐅𝐮𝐫𝐫𝐨_
║🔞 _${usedPrefix}𝐈𝐦𝐚𝐠𝐞𝐧𝐥𝐞𝐬𝐛𝐢𝐚𝐧𝐬_
║🔞 _${usedPrefix}𝐏𝐚𝐧𝐭𝐢𝐞𝐬_
║🔞 _${usedPrefix}𝐏𝐨𝐫𝐧𝐨_
║🔞 _${usedPrefix}𝐑𝐚𝐧𝐝𝐨𝐦𝐱𝐱𝐱_
║🔞 _${usedPrefix}𝐏𝐞𝐜𝐡𝐨𝐬_
║🔞 _${usedPrefix}𝐘𝐚𝐨𝐢_
║🔞 _${usedPrefix}𝐘𝐚𝐨𝐢𝟐_
║🔞 _${usedPrefix}𝐘𝐮𝐫𝐢_
║🔞 _${usedPrefix}𝐘𝐮𝐫𝐢𝟐_
║🔞 _${usedPrefix}𝐓𝐫𝐚𝐩𝐢𝐭𝐨_
║🔞 _${usedPrefix}𝐇𝐞𝐧𝐭𝐚𝐢𝐥_
║🔞 _${usedPrefix}𝐍𝐬𝐟𝐰𝐟𝐨𝐨𝐭_
║🔞 _${usedPrefix}𝐍𝐬𝐟𝐰𝐚𝐬𝐬_
║🔞 _${usedPrefix}𝐍𝐬𝐰𝐟𝐛𝐝𝐬𝐦_
║🔞 _${usedPrefix}𝐍𝐬𝐟𝐰𝐞𝐫𝐨_
║🔞 _${usedPrefix}𝐍𝐬𝐟𝐰𝐟𝐞𝐦𝐝𝐨𝐦_
║🔞 _${usedPrefix}𝐍𝐬𝐟𝐰𝐠𝐥𝐚𝐬𝐬_
╰═══〘 ❁❁❁❁❁❁❁ 〙═══╯
•❅──────✧❅✦❅✧──────❅•
╭═══〘 ❁❁❁❁❁❁❁ 〙═══╮
║           ❂𝐂𝐇𝐀𝐓 𝐀𝐍𝐎𝐍𝐈𝐌𝐎❂
║•❅─────✧❅✦❅✧─────❅•║
║° _${usedPrefix}𝐒𝐭𝐚𝐫𝐭_
║° _${usedPrefix}𝐍𝐞𝐱𝐭_
║° _${usedPrefix}𝐋𝐞𝐚𝐯𝐞_
╰═══〘 ❁❁❁❁❁❁❁ 〙═══╯

•❅──────✧❅✦❅✧──────❅•
╭═══〘 ❁❁❁❁❁❁❁ 〙═══╮
║          ❂𝐁𝐔𝐒𝐂𝐀𝐃𝐎𝐑𝐄𝐒❂
║•❅─────✧❅✦❅✧─────❅•║
║🔍 _${usedPrefix}𝐂𝐮𝐞𝐯𝐚𝐧𝐚 <𝐭𝐞𝐱𝐭𝐨>_
║🔍 _${usedPrefix}𝐏𝐞𝐥𝐢𝐬𝐩𝐥𝐮𝐬 <𝐭𝐞𝐱𝐭𝐨>_
║🔍 _${usedPrefix}𝐌𝐨𝐝𝐚𝐩𝐤 <𝐭𝐞𝐱𝐭𝐨>_
║🔍 _${usedPrefix}𝐒𝐭𝐢𝐜𝐤𝐞𝐫𝐬𝐞𝐚𝐫𝐜𝐡<𝐭𝐞𝐱𝐭𝐨>_
║🔍 _${usedPrefix}𝐒𝐭𝐢𝐜𝐤𝐞𝐫𝐬𝐞𝐚𝐫𝐜𝐡2 <𝐭𝐞𝐱𝐭𝐨>_
║🔍 _${usedPrefix}𝐗𝐧𝐱𝐱𝐬𝐞𝐚𝐫𝐜𝐡 <𝐭𝐞𝐱𝐭𝐨>_
║🔍 _${usedPrefix}𝐀𝐧𝐢𝐦𝐞𝐢𝐧𝐟𝐨 <𝐭𝐞𝐱𝐭𝐨>_
║🔍 _${usedPrefix}𝐆𝐨𝐨𝐠𝐥𝐞 <𝐭𝐞𝐱𝐭𝐨>_
║🔍 _${usedPrefix}𝐋𝐞𝐭𝐫𝐚 <𝐭𝐞𝐱𝐭𝐨>_
║🔍 _${usedPrefix}𝐖𝐢𝐤𝐢𝐩𝐞𝐝𝐢𝐚 <𝐭𝐞𝐱𝐭𝐨>_
║🔍 _${usedPrefix}𝐘𝐭𝐬𝐞𝐚𝐫𝐜𝐡 <𝐭𝐞𝐱𝐭𝐨>_
╰═══〘 ❁❁❁❁❁❁❁ 〙═══╯
•❅──────✧❅✦❅✧──────❅•
╭═══〘 ❁❁❁❁❁❁❁ 〙═══╮
║                ❂𝐀𝐔𝐃𝐈𝐎𝐒❂
║•❅─────✧❅✦❅✧─────❅•║
║𝐄𝐬𝐜𝐫𝐢𝐛𝐞 𝐥𝐚𝐬 𝐬𝐢𝐠𝐮𝐢𝐞𝐧𝐭𝐞𝐬 𝐩𝐚𝐥𝐚𝐛𝐫𝐚𝐬 𝐬𝐢𝐧 𝐩𝐫𝐞𝐟𝐢𝐣𝐨 (#, /,.)
║🔊 _𝐐𝐮𝐢𝐞𝐧 𝐞𝐬 𝐭𝐮 𝐬𝐞𝐦𝐩𝐚𝐢 𝐛𝐨𝐭𝐬𝐢𝐭𝐨 𝟕𝐰𝟕_
║🔊 _𝐓𝐞 𝐝𝐢𝐚𝐠𝐧𝐨𝐬𝐭𝐢𝐜𝐨 𝐜𝐨𝐧 𝐠𝐚𝐲_
║🔊 _𝐀 𝐧𝐚𝐝𝐢𝐞 𝐥𝐞 𝐢𝐦𝐩𝐨𝐫𝐭𝐚_
║🔊 _𝐅𝐢𝐞𝐬𝐭𝐚 𝐝𝐞𝐥 𝐚𝐝𝐦𝐢𝐧_
║🔊 _𝐅𝐢𝐞𝐬𝐭𝐚 𝐝𝐞𝐥 𝐚𝐝𝐦𝐢𝐧𝐢𝐬𝐭𝐫𝐚𝐝𝐨𝐫_ 
║🔊 _𝐕𝐢𝐯𝐚𝐧 𝐥𝐨𝐬 𝐧𝐨𝐯𝐢𝐨𝐬_
║🔊 _𝐅𝐞𝐥𝐢𝐳 𝐜𝐮𝐦𝐩𝐥𝐞𝐚ñ𝐨𝐬_
║🔊 _𝐍𝐨𝐜𝐡𝐞 𝐝𝐞 𝐩𝐚𝐳_
║🔊 _𝐁𝐮𝐞𝐧𝐨𝐬 𝐝𝐢𝐚𝐬_
║🔊 _𝐁𝐮𝐞𝐧𝐨𝐬 𝐭𝐚𝐫𝐝𝐞𝐬_
║🔊 _𝐁𝐮𝐞𝐧𝐨𝐬 𝐧𝐨𝐜𝐡𝐞𝐬_
║🔊 _𝐀𝐮𝐝𝐢𝐨 𝐡𝐞𝐧𝐭𝐚𝐢_
║🔊 _𝐂𝐡𝐢𝐜𝐚 𝐥𝐠𝐚𝐧𝐭𝐞_
║🔊 _𝐅𝐞𝐥𝐢𝐳 𝐧𝐚𝐯𝐢𝐝𝐚𝐝_
║🔊 _𝐕𝐞𝐭𝐞 𝐚 𝐥𝐚 𝐯𝐫𝐠_
║🔊 _𝐏𝐚𝐬𝐚 𝐩𝐚𝐜𝐤 𝐁𝐨𝐭_
║🔊 _𝐀𝐭𝐞𝐧𝐜𝐢𝐨𝐧 𝐠𝐫𝐮𝐩𝐨_
║🔊 _𝐌𝐚𝐫𝐢𝐜𝐚 𝐪𝐮𝐢𝐞𝐧_
║🔊 _𝐌𝐮𝐫𝐢𝐨 𝐞𝐥 𝐠𝐫𝐮𝐩𝐨_
║🔊 _𝐎𝐡 𝐦𝐞 𝐯𝐞𝐧𝐠𝐨_
║🔊 _𝐭𝐢𝐨 𝐪𝐮𝐞 𝐫𝐢𝐜𝐨_
║🔊 _𝐕𝐢𝐞𝐫𝐧𝐞𝐬_
║🔊 _𝐁𝐚𝐧𝐞𝐚𝐝𝐨_
║🔊 _𝐒𝐞𝐱𝐨_
║🔊 _𝐇𝐨𝐥𝐚_
║🔊 _𝐔𝐧 𝐩𝐚𝐭𝐨_
║🔊 _𝐍𝐲𝐚𝐧𝐩𝐚𝐬𝐮_
║🔊 _𝐓𝐞 𝐚𝐦𝐨_
║🔊 _𝐘𝐚𝐦𝐞𝐭𝐞_
║🔊 _𝐁𝐚ñ𝐚𝐭𝐞_
║🔊 _𝐄𝐬 𝐩𝐮𝐭𝐨_
║🔊 _𝐋𝐚 𝐛𝐢𝐛𝐥𝐢𝐚_
║🔊 _𝐎𝐧𝐢𝐜𝐡𝐚𝐧_
║🔊 _𝐌𝐢𝐞𝐫𝐝𝐚 𝐝𝐞 𝐁𝐨𝐭_
║🔊 _𝐒𝐢𝐮𝐮𝐮_
║🔊 _𝐄𝐩𝐢𝐜𝐨_
║🔊 _𝐒𝐡𝐢𝐭𝐩𝐨𝐬𝐭_
║🔊 _𝐑𝐚𝐰𝐫_
║🔊 _𝐔𝐰𝐔_
║🔊 _:𝐜_
║🔊 _𝐚_
╰═══〘 ❁❁❁❁❁❁❁ 〙═══╯
•❅──────✧❅✦❅✧──────❅•
╭═══〘 ❁❁❁❁❁❁❁ 〙═══╮
║       ❂𝐇𝐄𝐑𝐑𝐀𝐌𝐈𝐄𝐍𝐓𝐀𝐒❂
║•❅─────✧❅✦❅✧─────❅•║
║★ _${usedPrefix}𝐜𝐡𝐚𝐭𝐠𝐩𝐭 <𝐭𝐞𝐱𝐭𝐨>_
║★ _${usedPrefix}𝐜𝐡𝐚𝐭𝐠𝐩𝐭𝟐 <𝐭𝐞𝐱𝐭𝐨>_
║★ _${usedPrefix}𝐝𝐞𝐥𝐜𝐡𝐚𝐭𝐠𝐩𝐭_
║★ _${usedPrefix}𝐬𝐩𝐚𝐦𝐰𝐚 <𝐧𝐮𝐦𝐞𝐫𝐨|𝐭𝐞𝐱𝐭𝐨|𝐜𝐚𝐧𝐭𝐢𝐝𝐚𝐝>_
║★ _${usedPrefix}𝐜𝐥𝐢𝐦𝐚 <𝐩𝐚í𝐬> <𝐜𝐢𝐮𝐝𝐚𝐝>_
║★ _${usedPrefix}𝐞𝐧𝐜𝐮𝐞𝐬𝐭𝐚 <𝐭𝐞𝐱𝐭𝐨𝟏|𝐭𝐞𝐱𝐭𝐨𝟐>_
║★ _${usedPrefix}𝐚𝐟𝐤 <𝐦𝐨𝐭𝐢𝐯𝐨>_
║★ _${usedPrefix}𝐜𝐚𝐥𝐜 <𝐨𝐩𝐞𝐫𝐚𝐜𝐢𝐨𝐧 𝐦𝐚𝐭𝐡>_
║★ _${usedPrefix}𝐝𝐞𝐥 <𝐦𝐞𝐧𝐬𝐚𝐣𝐞>_
║★ _${usedPrefix}𝐫𝐞𝐚𝐝𝐪𝐫 <𝐢𝐦𝐚𝐠𝐞𝐧 (𝐐𝐑)>_
║★ _${usedPrefix}𝐪𝐫𝐜𝐨𝐝𝐞 <𝐭𝐞𝐱𝐭𝐨>_
║★ _${usedPrefix}𝐫𝐞𝐚𝐝𝐦𝐨𝐫𝐞 <𝐭𝐞𝐱𝐭𝐨𝟏�| 𝐭𝐞𝐱𝐭𝐨𝟐>_
║★ _${usedPrefix}𝐭𝐫𝐚𝐝𝐮𝐜𝐢𝐫 <𝐭𝐞𝐱𝐭𝐨>_
║★ _${usedPrefix}𝐭𝐫𝐚𝐝𝐮𝐜𝐢𝐫 <𝐭𝐞𝐱𝐭𝐨>_
╰═══〘 ❁❁❁❁❁❁❁ 〙═══╯
•❅──────✧❅✦❅✧──────❅•
╭═══〘 ❁❁❁❁❁❁❁ 〙═══╮
║        ❂𝗥𝗣𝗚/𝗘𝗖𝗢𝗡𝗢𝗠𝗜𝗔❂
║•❅────✧❅✦❅✧─────❅•║
║€  _${usedPrefix}𝐚𝐝𝐯𝐞𝐧𝐭𝐮𝐫𝐞_
║€  _${usedPrefix}𝐜𝐚𝐳𝐚𝐫_
║€  _${usedPrefix}𝐜𝐨𝐟𝐫𝐞_
║€  _${usedPrefix}𝐛𝐚𝐥𝐚𝐧𝐜𝐞_
║€  _${usedPrefix}𝐜𝐥𝐚𝐢𝐦_
║€  _${usedPrefix}𝐡𝐞𝐚𝐥_
║€  _${usedPrefix}𝐥𝐛_
║€  _${usedPrefix}𝐥𝐞𝐯𝐞𝐥𝐮𝐩_
║€  _${usedPrefix}𝐦𝐲𝐧𝐬_
║€  _${usedPrefix}𝐩𝐞𝐫𝐟𝐢𝐥_
║€  _${usedPrefix}𝐰𝐨𝐫𝐤_
║€  _${usedPrefix}𝐦𝐢𝐧𝐚𝐫_
║€  _${usedPrefix}𝐦𝐢𝐧𝐚𝐫𝟐_
║€  _${usedPrefix}𝐛𝐮𝐲_
║€  _${usedPrefix}𝐛𝐮𝐲𝐚𝐥𝐥_
║€  _${usedPrefix}𝐯𝐞𝐫𝐢𝐟𝐢𝐜𝐚𝐫_
║€  _${usedPrefix}𝐫𝐨𝐛𝐚𝐫 <𝐜𝐚𝐧𝐭𝐢𝐝𝐚𝐝> <@𝐭𝐚𝐠>_
║€  _${usedPrefix}.𝐭𝐫𝐚𝐧𝐬𝐟𝐞𝐫 <𝐭𝐢𝐩𝐨> <𝐜𝐚𝐧𝐭𝐢𝐝𝐚𝐝> <@𝐭𝐚𝐠>_
║€  _${usedPrefix}𝐮𝐧𝐫𝐞𝐠 <𝐧𝐮𝐦𝐞𝐫𝐨 𝐝𝐞 𝐬𝐞𝐫𝐢𝐞>_
╰═══〘 ❁❁❁❁❁❁❁ 〙═══╯
•❅──────✧❅✦❅✧──────❅•
╭═══〘 ❁❁❁❁❁❁❁ 〙═══╮
║             ❂𝐒𝐓𝐈𝐂𝐊𝐄𝐑𝐒❂
║•❅─────✧❅✦❅✧─────❅•║
║ ඬ⃟ 👽 _${usedPrefix}𝐬𝐭𝐢𝐜𝐤𝐞𝐫 <𝐫𝐞𝐬𝐩𝐨𝐧𝐝𝐞𝐫 𝐚 𝐢𝐦𝐚𝐠𝐞𝐧 𝐨 𝐯𝐢𝐝𝐞𝐨>_
║ ඬ⃟ 👽 _${usedPrefix}𝐬𝐭𝐢𝐜𝐤𝐞𝐫 <𝐞𝐧𝐥𝐚𝐜𝐞 / 𝐥𝐢𝐧𝐤 / 𝐮𝐫𝐥>_
║ ඬ⃟ 👽 _${usedPrefix}𝐬 <𝐫𝐞𝐬𝐩𝐨𝐧𝐝𝐞𝐫 𝐚 𝐢𝐦𝐚𝐠𝐞𝐧 𝐨 𝐯𝐢𝐝𝐞𝐨>_
║ ඬ⃟ 👽 _${usedPrefix}𝐬 <𝐞𝐧𝐥𝐚𝐜𝐞 / 𝐥𝐢𝐧𝐤 / 𝐮𝐫𝐥>_
║ ඬ⃟ 👽 _${usedPrefix}𝐬𝟐 <𝐫𝐞𝐬𝐩𝐨𝐧𝐝𝐞𝐫 𝐚 𝐢𝐦𝐚𝐠𝐞𝐧 𝐨 𝐯𝐢𝐝𝐞𝐨>_
║ ඬ⃟ 👽 _${usedPrefix}𝐞𝐦𝐨𝐣𝐢𝐦𝐢𝐱 <𝐞𝐦𝐨𝐣𝐢 𝟏>&<𝐞𝐦𝐨𝐣𝐢 𝟐>_
║ ඬ⃟ 👽 _${usedPrefix}𝐬𝐜𝐢𝐫𝐜𝐥𝐞 <𝐢𝐦𝐚𝐠𝐞𝐧>_
║ ඬ⃟ 👽 _${usedPrefix}𝐬𝐫𝐞𝐦𝐨𝐯𝐞𝐛𝐠 <𝐢𝐦𝐚𝐠𝐞𝐧>_
║ ඬ⃟ 👽 _${usedPrefix}𝐚𝐭𝐭𝐩(𝟐,𝟑) <𝐭𝐞𝐱𝐭𝐨>_
║ ඬ⃟ 👽 _${usedPrefix}𝐭𝐭𝐩 (𝟐,𝟑,𝟒) <𝐭𝐞𝐱𝐭𝐨>_
║ ඬ⃟ 👽 _${usedPrefix}𝐩𝐚𝐭 <@𝐭𝐚𝐠>_
║ ඬ⃟ 👽 _${usedPrefix}𝐬𝐥𝐚𝐩 <@𝐭𝐚𝐠>_
║ ඬ⃟ 👽 _${usedPrefix}𝐤𝐢𝐬𝐬 <@𝐭𝐚𝐠>_
║ ඬ⃟ 👽 _${usedPrefix}𝐬𝐭𝐢𝐜𝐤𝐞𝐫𝐦𝐚𝐫𝐤𝐞𝐫 <𝐞𝐟𝐞𝐜𝐭𝐨> <𝐢𝐦𝐚𝐠𝐞𝐧>_
║ ඬ⃟ 👽 _${usedPrefix}𝐬𝐭𝐢𝐜𝐤𝐞𝐫𝐟𝐢𝐥𝐭𝐞𝐫 <𝐞𝐟𝐞𝐜𝐭𝐨> <𝐢𝐦𝐚𝐠𝐞𝐧>_
╰═══〘 ❁❁❁❁❁❁❁❁ 〙═══╯
•❅──────✧❅✦❅✧──────❅•
╭═══〘 ❁❁❁❁❁❁❁❁ 〙═══╮
║❂𝐎𝐖𝐍𝐄𝐑 𝐘 𝐌𝐎𝐃𝐄𝐑𝐀𝐃𝐎𝐑𝐄𝐒❂
║•❅────✧❅✦❅✧────❅•║
║ ඬ⃟ 👑 > *<funcion>*
║ ඬ⃟ 👑 => *<funcion>*
║ ඬ⃟ 👑 $ *<funcion>*
║ ඬ⃟ 👑 _${usedPrefix}setprefix *<prefijo>*_
║ ඬ⃟ 👑 _${usedPrefix}desactivarwa *<numero>*_
║ඬ⃟  👑 _${usedPrefix}resetprefix_
║ ඬ⃟ 👑 _${usedPrefix}autoadmin_
║ ඬ⃟ 👑 _${usedPrefix}leavegc_
║ ඬ⃟ 👑 _${usedPrefix}cajafuerte_
║ඬ⃟  👑 _${usedPrefix}blocklist_
║ ඬ⃟ 👑 _${usedPrefix}block *<@tag / numero>*_
║ ඬ⃟ 👑 _${usedPrefix}unblock *<@tag / numero>*_
║ ඬ⃟ 👑 _${usedPrefix}enable *restrict*_
║ ඬ⃟ 👑 _${usedPrefix}disable *restrict*_
║ ඬ⃟ 👑 _${usedPrefix}enable *autoread*_
║ ඬ⃟ 👑 _${usedPrefix}disable *autoread*_
║ ඬ⃟ 👑 _${usedPrefix}enable *public*_
║ ඬ⃟ 👑 _${usedPrefix}disable *public*_
║ ඬ⃟ 👑 _${usedPrefix}enable *pconly*_
║ ඬ⃟ 👑 _${usedPrefix}disable *pconly*_
║ ඬ⃟ 👑 _${usedPrefix}enable *gconly*_
║ ඬ⃟ 👑 _${usedPrefix}disable *gconly*_
║ ඬ⃟ 👑 _${usedPrefix}enable *anticall*_
║ ඬ⃟ 👑 _${usedPrefix}disable *anticall*_
║ ඬ⃟ 👑 _${usedPrefix}enable *antiprivado*_
║ ඬ⃟ 👑 _${usedPrefix}disable *antiprivado*_
║ ඬ⃟ 👑 _${usedPrefix}enable *modejadibot*_
║ ඬ⃟ 👑 _${usedPrefix}disable *modejadibot*_
║ ඬ⃟ 👑 _${usedPrefix}msg *<texto>*_
║ ඬ⃟ 👑 _${usedPrefix}banchat_
║ ඬ⃟ 👑 _${usedPrefix}unbanchat_
║ ඬ⃟ 👑 _${usedPrefix}banuser *<@tag>*_
║ ඬ⃟ 👑 _${usedPrefix}unbanuser *<@tag>*_
║ ඬ⃟ 👑 _${usedPrefix}dardiamantes *<@tag>*_
║ ඬ⃟ 👑 _${usedPrefix}añadirxp *<@tag>*_
║ ඬ⃟ 👑 _${usedPrefix}banuser *<@tag>*_
║ ඬ⃟ 👑 _${usedPrefix}bc *<texto>*_
║ ඬ⃟ 👑 _${usedPrefix}bcchats *<texto>*_
║ ඬ⃟ 👑 _${usedPrefix}bcgc *<texto>*_
║ ඬ⃟ 👑 _${usedPrefix}bcgc2 *<audio>*_
║ ඬ⃟ 👑 _${usedPrefix}bcgc2 *<video>*_
║ ඬ⃟ 👑 _${usedPrefix}bcgc2 *<imagen>*_
║ ඬ⃟ 👑 _${usedPrefix}bcbot *<texto>*_
║ ඬ⃟ 👑 _${usedPrefix}cleartpm_
║ ඬ⃟ 👑 _${usedPrefix}restart_
║ ඬ⃟ 👑 _${usedPrefix}update_
║ ඬ⃟ 👑 _${usedPrefix}banlist_
║ ඬ⃟ 👑 _${usedPrefix}addprem *<@tag> <tiempo>*_
║ ඬ⃟ 👑 _${usedPrefix}addprem2 *<@tag> <tiempo>*_
║ ඬ⃟ 👑 _${usedPrefix}addprem3 *<@tag> <tiempo>*_
║ ඬ⃟ 👑 _${usedPrefix}addprem4 *<@tag> <tiempo>*_
║ ඬ⃟ 👑 _${usedPrefix}delprem *<@tag>*_
║ ඬ⃟ 👑 _${usedPrefix}listcmd_
║ ඬ⃟ 👑 _${usedPrefix}setppbot *<responder a imagen>*_
║ ඬ⃟ 👑 _${usedPrefix}addcmd *<texto> <responder a sticker/imagen>*_
║ ඬ⃟ 👑 _${usedPrefix}delcmd *<responder a sticker/imagen con comando o texto asignado>*_
╰═══〘 ❁❁❁❁❁❁❁ 〙═══╯
•❅─────✧❅✦❅✧─────❅•
╭═══〘 ❁❁❁❁❁❁❁❁ 〙═══╮
║     ❂𝐓𝐑𝐀𝐁𝐀𝐒 𝐘 𝐁𝐔𝐆𝐒❂
║•❅─────✧❅✦❅✧─────❅•║
║⚠️  _${usedPrefix}crash𝟷_
║⚠️  _${usedPrefix}crash2_
║⚠️  _${usedPrefix}crash3_
║⚠️  _${usedPrefix}crash4_
║⚠️  _${usedPrefix}crash5_
║⚠️  _${usedPrefix}crash6_
║⚠️  _${usedPrefix}crash7_
║⚠️  _${usedPrefix}crash8_
╰═══〘 ❁❁❁❁❁❁❁ 〙═══╯
༼ つ ◕_◕ ༽つ   uwu        ｡◕‿‿◕｡ `.trim();
    if (m.isGroup) {
      // await conn.sendFile(m.chat, vn, 'menu.mp3', null, m, true, { type: 'audioMessage', ptt: true})
      const fkontak2 = {'key': {'participants': '0@s.whatsapp.net', 'remoteJid': 'status@broadcast', 'fromMe': false, 'id': 'Halo'}, 'message': {'contactMessage': {'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`}}, 'participant': '0@s.whatsapp.net'};
      conn.sendMessage(m.chat, {image: pp, caption: str.trim(), mentions: [...str.matchAll(/@([0-9]{5,16}|0)/g)].map((v) => v[1] + '@s.whatsapp.net')}, {quoted: fkontak2});
    } else {
      // await conn.sendFile(m.chat, vn, 'menu.mp3', null, m, true, { type: 'audioMessage', ptt: true})
      const fkontak2 = {'key': {'participants': '0@s.whatsapp.net', 'remoteJid': 'status@broadcast', 'fromMe': false, 'id': 'Halo'}, 'message': {'contactMessage': {'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:Sy;Bot;;;\nFN:y\nitem1.TEL;waid=${m.sender.split('@')[0]}:${m.sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`}}, 'participant': '0@s.whatsapp.net'};
      conn.sendMessage(m.chat, {image: pp, mediaUrl: nn, sourceUrl: nn2, caption: str.trim(), mentions: [...str.matchAll(/@([0-9]{5,16}|0)/g)].map((v) => v[1] + '@s.whatsapp.net')}, {quoted: fkontak2});
    }
  } catch {
    conn.reply(m.chat, '*[❗𝐈𝐍𝐅𝐎❗] 𝙴𝙻 𝙼𝙴𝙽𝚄 𝚃𝙸𝙴𝙽𝙴 𝚄𝙽 𝙴𝚁𝚁𝙾𝚁 𝚈 𝙽𝙾 𝙵𝚄𝙴 𝙿𝙾𝚂𝙸𝙱𝙻𝙴 𝙴𝙽𝚅𝙸𝙰𝚁𝙻𝙾, 𝚁𝙴𝙿𝙾𝚁𝚃𝙴𝙻𝙾 𝙰𝙻 𝙿𝚁𝙾𝙿𝙸𝙴𝚃𝙰𝚁𝙸𝙾 𝙳𝙴𝙻 𝙱𝙾𝚃*', m);
  }
};
handler.command = /^(menu|menú|memu|memú|help|info|comandos|allmenu|2help|menu1.2|ayuda|commands|commandos|cmd)$/i;
handler.exp = 50;
handler.fail = null;
export default handler;
function clockString(ms) {
  const h = isNaN(ms) ? '--' : Math.floor(ms / 3600000);
  const m = isNaN(ms) ? '--' : Math.floor(ms / 60000) % 60;
  const s = isNaN(ms) ? '--' : Math.floor(ms / 1000) % 60;
  return [h, m, s].map((v) => v.toString().padStart(2, 0)).join(':');
}